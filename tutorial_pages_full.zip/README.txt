This package contains a small static tutorial site:
- index.html (home)
- style.css (shared stylesheet)
- pages/ (12 topic pages: 6 HTML / 6 CSS)

To view locally: open index.html in your browser. Ensure the pages/ folder and style.css remain next to index.html.
